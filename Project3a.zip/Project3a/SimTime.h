#if !(_Time_h)
#define _Time_h 1

typedef double SimTime;

#endif /* !(_Time_h) */

