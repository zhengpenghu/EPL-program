
enum Token {
  TOK_EOF = 0,
  TOK_INT,
  TOK_DOUBLE,
  TOK_ID
};
