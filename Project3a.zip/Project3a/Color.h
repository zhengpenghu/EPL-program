#if !(_Color_h)
#define _Color_h 1

enum Color {
  BLACK = 0,
  BLUE = 1,
  GREEN = 2,
  CYAN = 3,
  MAGENTA = 4,
  RED = 5,
  ORANGE = 6,
  YELLOW = 7
};


#endif /* !(_Color_h) */
